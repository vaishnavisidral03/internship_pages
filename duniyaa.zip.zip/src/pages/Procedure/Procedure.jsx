import React, { Component } from 'react';
//import Carousel from 'react-elastic-carousel';
//import img1 from "../assets/images/img1.png";
import "./procedure.css";
import {Container, Row, Col, Button,Accordion} from "react-bootstrap";
import Header from "../../components/Header";
import Footer from "../../components/Footer";

export default class Procedure extends Component {
  render () {
    return (
        <div>
          <Header />
             <div className='steps mt-5'>
             <Container>
                  <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0" className='help_steps'>
                    <Accordion.Header>Step 1 : Place Details</Accordion.Header>
                    <Accordion.Body>
                    <p><b>Q. 1. What does place details include?</b></p>
                    <p>
                    The place details are necessary while adding your business or any other place.It includes basic details.
                    </p>
                    <p>
                    You will be asked for the following information in place details:</p>
                    <ul>
                        <li>1. Shop/Office/Business/Place Name
                        <h6>Fill this tab with Business / Shop / Place / Office Name</h6>
                        </li>
                        <li>2. Place owner name<h6>Fill this tab with Place Owner Name</h6></li>
                        <li>3. Place registration date
                        <h6>It is the date from which you are running your business successfully till this date.</h6>
                        </li>
                        <li>4. Location / Address</li>
                    </ul>
                    <p>You are requested to fill all these details in the defined formats so that we can show Your place to our all users in an attractive manner.</p>
                    <p><b>Q. 2. What is Shop/Office/Business/Place Name?</b></p>
                    <p>
                      A business name is the name your business is known by. It might be your own personal name,  or  it  might  be  something  entirely  different  and  unique  to  your  business.  Your  business name will be used on daily basis, so it’s important that you pick the right one.</p>
                      <p><b>Q. 3. What is place owner name?</b></p>
                      <p>
                      A business owner is the legal proprietor of a business. An individual or group that owns he assets of a firm and profits from them.
                      </p>
                      <p>A place owner is a person who is responsible for all type of decisions, profits, losses, whodirects the business and controls its day-to-day processes.</p>
                      <p><b>Q. 4. What is place registration date ?</b></p>
                      <p>
                      It is the date on which you were started your business. Please provide such date so the we  can  show  your  age  of  your  business  i.e.  from  how  long  you  are  doing  your  business  which might you to reach maximum customers to you with your market reputation.</p>
                      <p><b>Q. 5. What is Landmark ?</b></p>
                      <p>
                      Landmark is a building or an object that helps you identify a location or the boundary of a piece of land. You are advised to add anything as landmark which is easy to identify, very known building, any general public place such as medical, hospital, school, college, church, etc. So that everyone can reach your place as soon as possible.</p>
                    </Accordion.Body>
                  </Accordion.Item>
    
                  <Accordion.Item eventKey="1" className='help_steps'>
                    <Accordion.Header>Step 2 : Nature of Business</Accordion.Header>
                    <Accordion.Body>
                       <p><b>Q. 1. What is Business or Place category ?</b></p>
                       <p>Category management is a word relating to retailing and purchasing concept in which the range of products purchased by a business organization or sold by a retailer is broken down into discrete groups of similar or related products; these groups are known as product categories. It is a systematic, disciplined approach to classify each type of business with their respective nature of work.</p>
                       <p><b>Q. 2. How to choose category for your Business / Place ?</b></p>
                       <p>For Shop, a place where people go to buy things, If your business includes purchase and sales, retail trade or directly linked to the customers, then select the option “Shop”.</p>
                       <p>For  Service,  If  your  business  includes  providing  any  service  like  banking,  agency, insurance,  etc.  then  choose  “Service”.  This  type  of  business  does  not  include  direct  selling  of physical goods.</p>
                       <p>For  Self  Employer,  A  self  employed  person  does  not  work  for  a  specific  employer  who pays them a consistent salary or wage. Self employed indviduals or independent contractors earn income by contracting with a trade or business directly.</p>
                       <p>For   Factory   /  Manufacturer,  Manufacturer   is  the  type  of   business  is  engaged  in manufacturing some product or someone who manufactures something while Factory is a plant consisting of one or more buildings with facilities for manufacturing.</p>
                       <p><b>Q. 3. How to describe your business / place ?</b></p>
                       <p>Describe your business / place with the following keypoints :</p>
                       <ul>
                          <li><h6>1. How long your business is running ?</h6></li>
                          <li><h6>2. Which type of products or services you are offering to your customers ?</h6></li>
                          <li><h6>3. How is your business different from others ?</h6></li>
                          <li><h6>4. What is the nature of your business ?</h6></li>
                          <li><h6>5. Write something about your business / place which attract users or customers reach upto you.</h6></li>
                          <li><h6>6. Others</h6></li>
                       </ul>
                       <p><b>Q. 4. Mobile Number</b></p>
                       <p>Please make sure mobile number you are provided is available for 24 X 7.</p>
                       <p><b>Q. 5. Email ID </b></p>
                       <p>Provide email ID if you have any and make sure it is active.</p>
                       <p><b>Q. 6. Business Website</b></p>
                       <p>Provide Business website if you have any.</p>
                       <p><b>Q. 7. What is Door Service ?</b></p>
                       <p>It  is  the  nothing  but  the  Home  Delivery  service.  Tap  Yes  if  you  provide  Door  Service  to your customers, Tap No if you are not providing the same. If you are desire to provide such service you can change the Door Service option from No to Yes.</p>
                       </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item eventKey="2" className='help_steps'>
                  <Accordion.Header>Step 3 : Place Availability</Accordion.Header>
                  <Accordion.Body>
                      <p><b>Q. 1. What is 24 X 7 service ?</b></p>
                      <p>You are requested to mention whether you make your business or service available for all time for your customers.</p>
                      <p>Tap Yes if you provide 24 X 7 service and tap No if you run your business within time limits every day.</p>
                      <p><b>Q. 2. What does the Working Days mean and How to set them ?</b></p>
                      <p>Working days are any days in which normal business operations are conducted.</p>
                      <p><b>Q. 3. How to set Working Hour Timings ?</b></p>
                      <p>These are the timings during which you open your shop in case you are retailer,these are the timings at which you open and close your service or business.</p>
                      <p><b>Q. 4. What does Lunch Hour Timings and How to set them ?</b></p>
                      <p>Lunch hour timings are the break during working timings. Let your customers know when they can visit your place as per both convenience.</p>
                      <p><b>Q. 5. What is exchange facility and How to set Exchange Hour Timings ?</b></p>
                      <p>In case one customer bought some stuff from you and they are found unsatisfactory on the next day, now they wish to replace the bought stuff with new stuff this is called exchange. Provide about such information whether you provide exchange facility or not and if yes on what time you avail this facility to your customers so that they will visit your place for exchange.</p>

                  </Accordion.Body>
                </Accordion.Item>
                <Accordion.Item eventKey="3" className='help_steps'>
                <Accordion.Header>Step 4 : List Out Your Products</Accordion.Header>
                <Accordion.Body>
                    <p><b>Q. 1. How to add Products ?</b></p>
                    <p>You can add your products in the following three ways :</p>
                       <ul>
                          <li><h6>1. Add own</h6></li>
                          <li><h6>2. Select From List</h6></li>
                          <li><h6>3. Search</h6></li>
                       </ul>
                       <p>
                       The products are showed in the list on the basis of selection of your subcategory of your business. If you find relative product you can add it to your product list. If you didn’t find your     product in the provided list you can add any product with the remaining options i. e. + Add Own and also with Voice Search Option which helps to add your products quickly.</p>
                       <p><b>Q. 2. How to edit Your Existing Products ?</b></p>
                       <p>You can also edit the products which are selected from the provided list. For example, you can change the quantity and unit as per your selling rule.</p>
                </Accordion.Body>
              </Accordion.Item>
              <Accordion.Item eventKey="4" className='help_steps'>
              <Accordion.Header>Step 5 : Upload Place Images</Accordion.Header>
              <Accordion.Body>
                  <p><b>Q. 1. How to add Products ?</b></p>
                  <p>You can add your products in the following three ways :</p>
                     <ul>
                        <li><h6>Q. 1. How to upload images ?</h6></li>
                        <li><h6>Q. 2. Which type of images one should upload ?</h6></li>
                        <li><h6>How can our photo editor help you to customize your existing place images or any image ?</h6></li>
                        <li><h6>Q. 4. How to make advertisement banner ?</h6></li>
                        <li><h6>Q. 5. How to delete added images ?</h6></li>
                        <li><h6>Q. 6. How to export image from photo editor ?
                        </h6></li>
                     </ul>
                    
              </Accordion.Body>
            </Accordion.Item>
                </Accordion>
             </Container>            
             </div>
          <Footer />
        </div>
    )
  }
}