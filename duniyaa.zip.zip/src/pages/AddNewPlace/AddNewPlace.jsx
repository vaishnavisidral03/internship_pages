import React, { Component } from 'react';
//import Carousel from 'react-elastic-carousel';
 import img1 from "../../assets/images/img1.png";
import "./addnewplace.css";
import {Tabs, Tab, Container, Row, Col, Button,Form} from "react-bootstrap";
import Header from "../../components/Header";
import Footer from "../../components/Footer";

export default class AddNewPlace extends Component {
  state = {
		shown: false,
	};
  render () {
 
    return (
        <div>
          <Header />
             <section className=''>
             <div className='add_bg'>
             <Container>
             <div className='add_title'>
                <Row> 
                  <Col md="8">
                    <h1>Add Place</h1>
                  </Col>
                  <Col md="4">
                    <h6><span>Add Place</span> / Upload Place Images</h6>
                  </Col>
                </Row>
                   
                </div>
             </Container>
             </div>
              <Container>     
                      
                <div className='add_place_tab'>
                  <Tabs defaultActiveKey="placedetails" id="uncontrolled-tab-example" className="mb-3 tab_class">
                  <Tab eventKey="placedetails" title={<span><i className='fa fa-map-marker'></i> <br /> Place Details  </span>}>
                    <Row>
                    <Col md="3"></Col>
                    <Col md="6">
                    <Form className="placeinfo">
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                      <Form.Label>Shop / Office / Business / Place Name</Form.Label>
                      <Form.Control type="email" placeholder="Enter email" />
                     
                    </Form.Group>
                  
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                      <Form.Label>Place Owner Name</Form.Label>
                      <Form.Control type="text" placeholder="Place Owner Name" />
                    </Form.Group>
                   
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                      <Form.Label>Place Reg Date</Form.Label>
                      <Form.Control type="date" placeholder="Place Reg Date" />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                      <Form.Label>Shop / Office / Business / Place Address</Form.Label>
                      <Form.Control as="textarea" rows={3} />
                      <Form.Text className="text-muted">
                     Make sure entered address is complete, correct and it is yoyr Shop/ Office / business location address.
                    </Form.Text>
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicPassword">
                      <Form.Label>Landmark</Form.Label>
                      <Form.Control type="text" placeholder="Place Reg Date" />
                    </Form.Group>
                    <div className=''><a href="#."><i className="fa fa-map-marker"></i> Fetch current location</a></div>
                    <Row className="place_btn">
                    <Col md="6">
                    <Button variant="primary" type="submit" className="opacity_class">
                    <i className='fa fa-angle-left' /> Previous
                  </Button>
                    </Col>
                    <Col md="6">
                    <Button variant="primary" type="submit" className="pull-right">
                    Next <i className='fa fa-angle-right' />
                  </Button>
                    </Col>
                 </Row>
                   
                </Form>
                    </Col>
                    <Col md="3"></Col>
                  </Row>    
                    
                  </Tab>
                  <Tab eventKey="business" title={<span><i className='fa fa-briefcase'></i> <br /> Nature of Business  </span>}>
                  <Form className="placeinfo">
                  <Form.Group className="mb-3" controlId="formBasicEmail">
                       
                    <Row>
                    <Col md="2"></Col>
                    <Col md="8">
                    <Form.Label>Choose type of business / Place and Category</Form.Label>  
                       <ul className='place_cat'>
                         <li><Button onClick={() => this.setState({ shown: !this.state.shown })}>Shop</Button></li>
                         <li><Button>Services</Button></li>
                         <li><Button>Shop</Button></li>
                         <li><Button>Services</Button></li>
                         <li><Button>Shop</Button></li>
                         <li><Button>Services</Button></li>
                       </ul>
                    </Col>
                    <Col md="2"></Col>
                 </Row>                               
                  </Form.Group>
                     
                    
                      <Row>
                        <Col md="3"></Col>
                        <Col md="6">
                          
                          <Form.Group controlId="formBasicPassword">
                          <Form.Label>More Details about place :</Form.Label>
                         
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                        {this.state.shown ? (
                          <>
                          <Form.Label>Search For Categories</Form.Label>
                        <Form.Select aria-label="Default select example">
                          <option>Open this select menu</option>
                          <option value="1">One</option>
                          <option value="2">Two</option>
                          <option value="3">Three</option>
                        </Form.Select>
                        </>
                        ) : ""}
                        
                      </Form.Group>
                      <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                        <Form.Label>Describe your place / business in few words</Form.Label>
                        <Form.Control as="textarea" rows={3} />                      
                      </Form.Group>
                        <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Row>
                           <Col md="4">
                              <Form.Label>Mobile No.</Form.Label>
                            <Form.Control type="date" placeholder="Mobile No." />
                            </Col>
                           <Col md="8">
                           <Form.Label>Email ID</Form.Label>
                           <Form.Control type="date" placeholder="Email ID" />
                           </Col>
                        </Row>
                        
                      </Form.Group>
                      <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Business Website (If Any)</Form.Label>
                        <Form.Control type="date" placeholder="Business Website (If Any)" />
                      </Form.Group>
                      <Form.Group as={Row} className="mb-3">
                      <Form.Label as="legend" column sm={5}>
                        Do you have door services : 
                      </Form.Label>
                      <Col sm={2}>
                        <Form.Check
                          type="radio"
                          label="Yes"
                          name="formHorizontalRadios"
                          id="formHorizontalRadios1"
                        />
                        </Col>
                        <Col sm={2}>
                        <Form.Check
                          type="radio"
                          label="No"
                          name="formHorizontalRadios"
                          id="formHorizontalRadios2"
                        />
                     
                        </Col>
                    </Form.Group>
                    <Row className="place_btn">
                      <Col md="6">
                      <Button variant="primary" type="submit">
                      <i className='fa fa-angle-left' /> Prevoius
                    </Button>
                      </Col>
                      <Col md="6">
                      <Button variant="primary" type="submit" className="pull-right">
                      Next <i className='fa fa-angle-right' />
                    </Button>
                      </Col>
                   </Row>
                        </Col>
                        <Col md="3"></Col>
                      </Row>
                   
                    </Form>
                  </Tab>
                  <Tab eventKey="placeavailaibility" title={<span><i className='fa fa-location-arrow'></i> <br /> Place Availaibility  </span>}>
                  <Row>
                  <Col md="3"></Col>
                  <Col md="6">
                    <Form className='placeinfo'>
                    <Form.Group as={Row} className="mb-2">
                      <Form.Label as="legend" column sm={5}>
                        Do you provide 24 * 7 Service : 
                      </Form.Label>
                      :
                      <Col sm={2}>
                        <Form.Check
                          type="radio"
                          label="Yes"
                          name="formHorizontalRadios"
                          id="formHorizontalRadios1"
                        />
                        </Col>
                        <Col sm={2}>
                        <Form.Check
                          type="radio"
                          label="No"
                          name="formHorizontalRadios"
                          id="formHorizontalRadios2"
                        />
                     
                        </Col>
                    </Form.Group>
                    <Form.Group as={Row} className="mb-2">
                    <Form.Label as="legend" column sm={5}>
                      Working Days : 
                    </Form.Label>
                    :
                    <Col sm={6}>
                      <div className='days-btn'>
                       {/** <Button>S</Button>
                        <Button>M</Button>
                        <Button>T</Button>
                        <Button>W</Button>
                        <Button>T</Button>
                        <Button>F</Button>
                        <Button>S</Button>**/}
                        <div class="cat action">
                          <label>
                              <input type="checkbox" value="1" /><span>S</span>
                          </label>
                        </div>

                        <div class="cat comedy">
                          <label>
                              <input type="checkbox" value="1" /><span>M</span>
                          </label>
                        </div>

                        <div class="cat crime">
                          <label>
                              <input type="checkbox" value="1" /><span>T</span>
                          </label>
                        </div>

                        <div class="cat history">
                          <label>
                              <input type="checkbox" value="1" /><span>W</span>
                          </label>
                        </div>

                        <div class="cat reality">
                          <label>
                              <input type="checkbox" value="1" /><span>T</span>
                          </label>
                        </div>

                        <div class="cat news">
                          <label>
                              <input type="checkbox" value="1" /><span>f</span>
                          </label>
                        </div>

                          <div class="cat scifi">
                          <label>
                              <input type="checkbox" value="1" /><span>S</span>
                          </label>
                        </div>

                      </div>                    
                    </Col>
                  </Form.Group>
                    <Form.Group as={Row} className="mb-2">
                    <Form.Label as="legend" column sm={5}>
                     Working hour timing
                    </Form.Label>
                    :
                    <Col sm={2}>
                      <Form.Select aria-label="Default select example" className="hours">                 
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                    </Form.Select>
                      </Col>
                      <Col sm={1}><p>to</p></Col>
                      <Col sm={2}>
                        <Form.Select aria-label="Default select example" className="hours">                 
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                      </Form.Select>
                   
                      </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-2">
                  <Form.Label as="legend" column sm={5}>
                   Lunch hour timing
                  </Form.Label>
                  :
                  <Col sm={4}>
                  <Form.Check type="checkbox" label="No Lunch Hours" />
                
                    </Col>
                   
                </Form.Group>
                <Form.Group as={Row} className="mb-2">
                <Form.Label as="legend" column sm={5}>
               
                </Form.Label>
                :
                <Col sm={2}>
                <Form.Select aria-label="Default select example" className="hours">                 
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
              </Form.Select>
              
                  </Col>
                  <Col sm={1}><p>to</p></Col>
                  <Col sm={2}>
                  <Form.Select aria-label="Default select example" className="hours">                 
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                </Form.Select>
                
                    </Col>
              </Form.Group>
                    <Form.Group as={Row} className="mb-2">
                    <Form.Label as="legend" column sm={5}>
                      Do you provide exchange facility 
                    </Form.Label>
                    :
                    <Col sm={2}>
                    
                      <Form.Check
                        type="radio"
                        label="Yes"
                        name="formHorizontalRadios"
                        id="formHorizontalRadios1"
                      />
                      </Col>
                      <Col sm={2}>
                      <Form.Check
                        type="radio"
                        label="No"
                        name="formHorizontalRadios"
                        id="formHorizontalRadios2"
                      />
                   
                      </Col>
                  </Form.Group>
                  <Form.Group as={Row} className="mb-2">
                  <Form.Label as="legend" column sm={5}>
                   Exchange hour timing
                  </Form.Label>
                  :
                  <Col sm={2}>
                    <Form.Select aria-label="Default select example" className="hours">                 
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                  </Form.Select>
                  
                    </Col>
                    <Col sm={1}><p>to</p></Col>
                    <Col sm={2}>
                      <Form.Select aria-label="Default select example" className="hours">                 
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                    </Form.Select>
                 
                    </Col>
                    </Form.Group>
                    <Form.Group as={Row} className="mb-2">
                    <Form.Label as="legend" column sm={5}>
                  
                    </Form.Label>
                    :
                    <Col sm={6}>
                    
                    <Form.Check type="checkbox" label="Any time during working hours" />
                  
                      </Col>
                     
                      </Form.Group>
                      <Row className="place_btn">
                      <Col md="6">
                      <Button variant="primary" type="submit">
                      <i className='fa fa-angle-left' /> Prevoius
                    </Button>
                      </Col>
                      <Col md="6">
                      <Button variant="primary" type="submit" className="pull-right">
                      Next <i className='fa fa-angle-right' />
                    </Button>
                      </Col>
                   </Row>
                    </Form>
                  </Col>
                  <Col md="3"></Col>
                  </Row>
                  </Tab>
                  <Tab eventKey="uploadimage" title={<span><i className='fa fa-file-image-o'></i> <br /> Upload Place Images  </span>}>
                  <Row>
                  <Col md="3"></Col>
                  <Col md="6">
                  <Form className="placeinfo">
                  <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Upload Images</Form.Label>
                    <Form.Control type="file" placeholder="Enter email" className='uploadimg'/>
                   
                  </Form.Group>
                
                
                  <div className=''><p>You have added 0 images</p></div>
                  <Row className="place_btn">
                  <Col md="6">
                  <Button variant="primary" type="submit">
                  <i className='fa fa-angle-left' /> Prevoius
                </Button>
                  </Col>
                  <Col md="6">
                  <Button variant="primary" type="submit" className="pull-right">
                  Next <i className='fa fa-angle-right' />
                </Button>
                  </Col>
               </Row>
                 
              </Form>
                  </Col>
                  <Col md="3"></Col>
                </Row>    
                  </Tab>
                </Tabs>
                </div>
              </Container>
             </section>             
          <Footer />
      </div>
    )
  }
}