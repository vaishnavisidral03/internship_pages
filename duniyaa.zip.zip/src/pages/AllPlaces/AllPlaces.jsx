import React, { Component } from 'react';
//import Carousel from 'react-elastic-carousel';
import img1 from "../../assets/images/img1.png";
import map from "../../assets/images/map.png";
import hands1 from "../../assets/images/hands1.png";
import posts from "../../assets/images/posts.png";
import "./allplaces.css";
import {Container, Row, Col, Button, Form, InputGroup, FormControl, Tab, Nav, Tabs} from "react-bootstrap";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import HelpingHandPost from "../../components/HelpingHandPost.jsx";
import Post from "../../components/Post.jsx";

import Newplaces from "../../components/Newplaces";

export default class AllPlaces extends Component {
 
  render () {
 
    return (
        <div>
           <Header />
              <section>
                 <Container>
                    <div className='cetegory_top'>
                    <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                        <Row>
                        <Col md="3">
                            <div className='cetegory_left'>
                               {/*  <ul>
                                    <li><a href="#."> PLACES FOR YOU</a></li>
                                    <li><a href="#."> POSTS</a></li>
                                    <li><a href="#."> HELPING HANDS</a></li>
                                </ul>*/}
                                <Nav variant="pills" className="flex-column">
                                <Nav.Item>
                                <Nav.Link eventKey="first"><i className='fa fa-map-marker'></i> Places For You</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                <Nav.Link eventKey="second"><i className='fa fa-tags'></i> Posts</Nav.Link>
                                </Nav.Item>
                                <Nav.Link eventKey="third"><i className='fa fa-map-marker'></i> Helping Hands</Nav.Link>
                                
                            </Nav> 
                             {/*  <div className='recommanded_place'>
                                <h5>Recommanded Places <span><i className='fa fa-long-arrow-right'></i></span></h5>
                                <ul>
                                   <li className='place1'>
                                      <a href="#.">
                                      <Row>
                                          <Col md="4">
                                              <img src={img1} alt="place1" />
                                          </Col>
                                          <Col md="8">
                                              <h5>Uphar Bakery</h5>
                                              <p>Bakery Shop</p>
                                          </Col>
                                      </Row>
                                      </a>
                                   </li>
                                   <li className='place1'>
                                      <a href="#.">
                                      <Row>
                                          <Col md="4">
                                              <img src={img1} alt="place1" />
                                          </Col>
                                          <Col md="8">
                                              <h5>Uphar Bakery</h5>
                                              <p>Bakery Shop</p>
                                          </Col>
                                      </Row>
                                      </a>
                                   </li>
                                   <li className='place1'>
                                      <a href="#.">
                                      <Row>
                                          <Col md="4">
                                              <img src={img1} alt="place1" />
                                          </Col>
                                          <Col md="8">
                                              <h5>Uphar Bakery</h5>
                                              <p>Bakery Shop</p>
                                          </Col>
                                      </Row>
                                      </a>
                                   </li>
                                </ul>

                                </div>*/}  
                             
                            
                            </div>
                            
                        </Col>
                        <Col md="9">                        
                          
                           <Tab.Content>
                           <Tab.Pane eventKey="first">
                           <Row>
                           <div className='search_place mt-0'>                                                          
                                <Row>
                                   <Col md="9">
                                   
                                       <Row>
                                        <Form>
                                        {/*   <Form.Control
                                            type="text"
                                            id="Search Place"
                                            className='searchbar fa fa-user'
                                            aria-describedby="searchplaceBlock"
                                            placeholder="Search Place"
                                            />*/}  
                                            <InputGroup className="mb-3  ">
                                                <InputGroup.Text id="basic-addon1"><i className='fa fa-search'></i></InputGroup.Text>
                                                <FormControl
                                                className='searchbar'
                                                placeholder="Serach"
                                                aria-label="Username"
                                                aria-describedby="basic-addon1"
                                                />
                                            </InputGroup>
                                        </Form>
                                       </Row>
                                   </Col>
                                   <Col md="3">
                                        <a href="/AddNewPlace" className="add_place_div"><i className="fa fa-plus"></i> Add Place</a>
                                   </Col>
                                </Row>
                                
                           </div>
                           
                           </Row>
                           <Tabs
                                defaultActiveKey="home"
                                transition={false}
                                id="noanim-tab-example"
                                className="mb-3 category_title"
                                >
                                <Tab eventKey="home" title="Places">
                                    <div className='all_place'>
                                    <h6>NEWLY ADDED PLACES</h6>
                                    <Newplaces />
                                        </div>
                                        <div className='all_place'>
                                        <h6>MOST POPULAR IN CITY</h6>
                                    <Newplaces />
                                    </div>
                                    <div className='all_place'>
                                        <h6>RECOMMANDED PLACES</h6>
                                    <Newplaces />
                                    </div>
                                </Tab>
                                <Tab eventKey="profile" title="Offers">
                                    a
                                </Tab>
                                <Tab eventKey="contact" title="Categories">
                                    b
                                </Tab>
                                </Tabs>
                              
                           </Tab.Pane>
                           <Tab.Pane eventKey="second">
                           <Row>
                           <div className='search_place mt-0'>                                                          
                                <Row>
                                   <Col md="9">
                                   
                                       <Row>
                                        <Form>
                                        {/*   <Form.Control
                                            type="text"
                                            id="Search Place"
                                            className='searchbar fa fa-user'
                                            aria-describedby="searchplaceBlock"
                                            placeholder="Search Place"
                                            />*/}  
                                            <InputGroup className="mb-3  ">
                                                <InputGroup.Text id="basic-addon1"><i className='fa fa-search'></i></InputGroup.Text>
                                                <FormControl
                                                className='searchbar'
                                                placeholder="Serach"
                                                aria-label="Username"
                                                aria-describedby="basic-addon1"
                                                />
                                            </InputGroup>
                                        </Form>
                                       </Row>
                                   </Col>
                                   <Col md="3">
                                        <Button className="add_place_div"><i className="fa fa-plus"></i> Add Post</Button>
                                   </Col>
                                </Row>
                                
                           </div>
                           
                           </Row>
                           <Post />
                           </Tab.Pane>
                           <Tab.Pane eventKey="third">
                           <Row>
                           <div className='search_place mt-0'>                                                          
                                <Row>
                                   <Col md="9">
                                   
                                       <Row>
                                        <Form>
                                        {/*   <Form.Control
                                            type="text"
                                            id="Search Place"
                                            className='searchbar fa fa-user'
                                            aria-describedby="searchplaceBlock"
                                            placeholder="Search Place"
                                            />*/}  
                                            <InputGroup className="mb-3  ">
                                                <InputGroup.Text id="basic-addon1"><i className='fa fa-search'></i></InputGroup.Text>
                                                <FormControl
                                                className='searchbar'
                                                placeholder="Serach"
                                                aria-label="Username"
                                                aria-describedby="basic-addon1"
                                                />
                                            </InputGroup>
                                        </Form>
                                       </Row>
                                   </Col>
                                   <Col md="3">
                                        <Button className="add_place_div"><i className="fa fa-plus"></i> Add Post</Button>
                                   </Col>
                                </Row>
                                
                           </div>
                           
                           </Row>
                              <HelpingHandPost />
                           </Tab.Pane>
                         </Tab.Content>
                        </Col>
                        </Row>
                    </Tab.Container>
                    </div>
                 </Container>
              </section>
          {/*  <Footer /> */}
        </div>
    )
  }
}