import React from "react";
//import logo from "./logo.svg";
//import "./assets/css/style.css";
//import "./assets/css/responsive.css";
//import Header from "../src/components/header/Headertop";
//import "bootstrap/dist/css/bootstrap.min.css";
 import About from "./pages/About.js";
import Homepage from "./pages/Homepage.js";
import Login from "./pages/Login/Login.jsx";
import HelpingHands from "./pages/HelpingHands/HelpingHands.js";
import AddNewPlace from "./pages/AddNewPlace/AddNewPlace.jsx";
import SearchedPlace from "./pages/SearchedPlace/SearchedPlace.jsx";
import EditPlace from "./pages/EditPlace/EditPlace.jsx";
import AllPlaces from "./pages/AllPlaces/AllPlaces.jsx";
import MyPlaces from "./pages/MyPlaces/MyPlaces.jsx";
import Procedure from "./pages/Procedure/Procedure.jsx";
import Procedure1 from "./pages/Procedure/Procedure1.jsx";
import Procedure2 from "./pages/Procedure/Procedure2.jsx";

import {
  BrowserRouter as Router,
  Route,
 // Link,
  Routes,
 // Redirect,
} from "react-router-dom";
// import TermsConditions from "./pages/TermsConditions/TermsConditions.jsx";
function App() {
  return (
    <Router>
      <Routes>
        {/* Common Route Start 
        <Route exact path="/MyWishlist" component={MyWishlist} />*/}
        <Route exact path="/" element={<Homepage />} />
        <Route exact path="/About" element={<About />} />
        <Route exact path="/Login" element={<Login />} />       
        <Route exact path="/HelpingHands" element={<HelpingHands />} />
        <Route exact path="/AddNewPlace" element={<AddNewPlace />} />
        <Route exact path="/SearchedPlace" element={<SearchedPlace />} />
        <Route exact path="/EditPlace" element={<EditPlace />} />
        <Route exact path="/AllPlaces" element={<AllPlaces />} />
        <Route exact path="/MyPlaces" element={<MyPlaces />} />
        <Route exact path="/Procedure" element={<Procedure />} />
        <Route exact path="/Procedure1" element={<Procedure1 />} />
        <Route exact path="/Procedure2" element={<Procedure2 />} />
      </Routes>
    </Router>
  );
}

export default App;
