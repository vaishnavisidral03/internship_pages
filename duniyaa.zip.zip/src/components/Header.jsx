
import React, { Component } from 'react';

import "./addedplace.css";
import {Navbar, Nav, Container} from "react-bootstrap";


function Header()
{
  return (
    <div>
    <header className="">
  <Navbar collapseOnSelect expand="lg" className="pt-0 pb-0 header">
    <Container>
    <Navbar.Brand href="/" className="lg"><span>D</span><span className='lgnm'>Duniyaa Web App</span></Navbar.Brand>
    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
    <Navbar.Collapse id="responsive-navbar-nav">
      <Nav className="me-auto">
      
      </Nav>
      <Nav className="nav-header">
        <Nav.Link href="/">Home</Nav.Link>
      {/* <Nav.Link eventKey={2} href="/About">            
        About
        </Nav.Link>*/} 
        <Nav.Link href="/AddNewPlace">Add New Place</Nav.Link>
        {/* <Nav.Link href="#deets">Contact</Nav.Link>*/}
        
        <Nav.Link href="/MyPlaces">My Places</Nav.Link>
        <Nav.Link href="/Procedure" className='help_icon'><i className='fa fa-question-circle'></i></Nav.Link>
        <Nav.Link href="/Procedure1" className='help_icon'>Procedure 1</Nav.Link>
        <Nav.Link href="/Procedure2" className='help_icon'>Procedure 2</Nav.Link>
        <Nav.Link eventKey={2} href="/Login">
        Login
        </Nav.Link>
      </Nav>
    </Navbar.Collapse>
    </Container>
  </Navbar>
  </header>
</div>
)
}
/*
export default class Header extends Component {
  render () {  
    
  }
}*/
export default Header;