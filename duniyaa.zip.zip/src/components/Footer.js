import React, { Component } from 'react';
//import Carousel from 'react-elastic-carousel';
//import img1 from "../assets/images/img1.png";
//import "../../addedplace.css";
import {Container, Row, Col} from "react-bootstrap";
export default class About extends Component {
 
  render () {
 
    return (
        <div>
        <footer>
        <Container>
        <Row>
          <Col md="6">
            <div className='footer'>
            <h1>Duniyaa Web App</h1>
            <p>
            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been 
            the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type 
            and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap 
            into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s
            </p>
          </div>
          </Col>
          <Col md="6">
            <div className='download'>
               <h5>Download an Duniyaa app on</h5>
            </div>
          </Col>
        </Row>
        
        </Container>
        </footer>
      </div>
    )
  }
}